import java.sql.*;
public class IssueItemDao {
	
public static boolean checkBook(String Item_no){
	boolean status=false;
	try{
		Connection con=DB.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from Items where Itemno=?");
		ps.setString(1,Item_no);
	    ResultSet rs=ps.executeQuery();
		status=rs.next();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static int save(String Item_no,int personid,String personname,String personcontact){
	int status=0;
	try{
		Connection con=DB.getConnection();
		
		status=updatebook(Item_no);//updating quantity and issue
		
		if(status>0){
		PreparedStatement ps=con.prepareStatement("insert into issueitems(Item_no,personid,personname,personcontact) values(?,?,?,?)");
		ps.setString(1,Item_no);
		ps.setInt(2,personid);
		ps.setString(3,personname);
		ps.setString(4,personcontact);
		status=ps.executeUpdate();
		}
		
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static int updatebook(String Item_no){
	int status=0;
	int quantity=0,issued=0;
	try{
		Connection con=DB.getConnection();
		
		PreparedStatement ps=con.prepareStatement("select quantity,issued from Items where Itemno=?");
		ps.setString(1,Item_no);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			quantity=rs.getInt("quantity");
			issued=rs.getInt("issued");
		}
		
		if(quantity>0){
		PreparedStatement ps2=con.prepareStatement("update Items set quantity=?,issued=? where Itemno=?");
		ps2.setInt(1,quantity-1);
		ps2.setInt(2,issued+1);
		ps2.setString(3,Item_no);
		
		status=ps2.executeUpdate();
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
}
