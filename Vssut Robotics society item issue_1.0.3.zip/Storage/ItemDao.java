import java.sql.Connection;
import java.sql.PreparedStatement;

public class ItemDao {
public static int save(String Itemno,String Itemname,String Itemtype,String Itemstate,int quantity){
	int status=0;
	try{
		Connection con=DB.getConnection();
		PreparedStatement ps=con.prepareStatement("insert into Items(Itemno,Itemname,Itemtype,Itemstate,quantity) values(?,?,?,?,?)");
		ps.setString(1,Itemno);
		ps.setString(2,Itemname);
		ps.setString(3,Itemtype);
		ps.setString(4,Itemstate);
		ps.setInt(5,quantity);
		status=ps.executeUpdate();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
}
